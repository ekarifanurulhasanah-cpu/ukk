
<?php
session_start();
include "koneksi.php";
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['no_tlpn'];

    $stmt = mysqli_prepare($koneksi, "INSERT INTO pelanggan (nama_pelanggan, alamat, no_tlpn) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sss", $nama, $alamat, $telepon);
    mysqli_stmt_execute($stmt);

    header("Location: pelanggan.php");
    exit;
}

if (isset($_POST['update'])) {
    $id = $_POST['id_pelanggan'];
    $nama = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['no_tlpn'];

    $stmt = mysqli_prepare($koneksi, "UPDATE pelanggan SET nama_pelanggan=?, alamat=?, no_tlpn=? WHERE id_pelanggan=?");
    mysqli_stmt_bind_param($stmt, "sssi", $nama, $alamat, $telepon, $id);
    mysqli_stmt_execute($stmt);

    header("Location: pelanggan.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    $stmt = mysqli_prepare($koneksi, "DELETE FROM pelanggan WHERE id_pelanggan=?");
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (!mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Pelanggan tidak dapat dihapus karena sudah digunakan dalam transaksi.'); window.location='pelanggan.php';</script>";
        exit;
    }

    header("Location: pelanggan.php");
    exit;
}

$edit = null;

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM pelanggan WHERE id_pelanggan=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$data = mysqli_query($koneksi, "SELECT * FROM pelanggan ORDER BY id_pelanggan DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pelanggan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Data Pelanggan</h2>
    <a href="dashboard.php" class="btn-dashboard">Kembali ke Dashboard</a>

    <form method="POST">
        <input type="hidden" name="id_pelanggan" value="<?= $edit['id_pelanggan'] ?? '' ?>">

        <label>Nama Pelanggan</label>
        <input type="text" name="nama_pelanggan" value="<?= htmlspecialchars($edit['nama_pelanggan'] ?? '') ?>" required>

        <label>Alamat</label>
        <textarea name="alamat" required><?= htmlspecialchars($edit['alamat'] ?? '') ?></textarea>

        <label>Nomor Telepon</label>
        <input type="text" name="no_tlpn" value="<?= htmlspecialchars($edit['no_tlpn'] ?? '') ?>" required>

        <?php if ($edit) { ?>
            <button type="submit" name="update">Update Pelanggan</button>
            <a href="pelanggan.php" class="btn-batal">Batal</a>
        <?php } else { ?>
            <button type="submit" name="simpan">Tambah Pelanggan</button>
        <?php } ?>
    </form>

    <h3>Daftar Pelanggan</h3>
    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Nomor Telepon</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['nama_pelanggan']) ?></td>
            <td><?= htmlspecialchars($row['alamat']) ?></td>
            <td><?= htmlspecialchars($row['no_tlpn']) ?></td>
            <td>
                <a class="btn-edit" href="pelanggan.php?edit=<?= $row['id_pelanggan'] ?>">Edit</a>
                <a class="btn-hapus" href="pelanggan.php?hapus=<?= $row['id_pelanggan'] ?>" onclick="return confirm('Hapus pelanggan ini?')">Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>

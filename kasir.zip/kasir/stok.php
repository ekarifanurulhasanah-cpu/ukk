
<?php
session_start();
include "koneksi.php";
if (isset($_POST['ubah'])) {
    $id = (int)$_POST['idproduk'];
    $stok = filter_var($_POST['stok'], FILTER_VALIDATE_INT);

    if ($stok !== false && $stok >= 0) {
        $query = mysqli_prepare(
            $koneksi,
            "UPDATE produk SET stok = ? WHERE idproduk = ?"
        );

        mysqli_stmt_bind_param($query, "ii", $stok, $id);
        mysqli_stmt_execute($query);
    }

    header("Location: stok.php");
    exit;
}

$data = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY namaproduk ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stok Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Pengaturan Stok Barang</h2>

    <div class="table-wrap">
        <table>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Stok</th>
                <th>Ubah Stok</th>
            </tr>

            <?php $no = 1; ?>
            <?php while ($row = mysqli_fetch_assoc($data)) { ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo htmlspecialchars($row['namaproduk']); ?></td>
                <td><?php echo $row['stok']; ?></td>
                <td>
                    <form method="POST" class="inline-form">
                        <input type="hidden" name="idproduk"
                            value="<?php echo $row['idproduk']; ?>">

                        <input type="number" name="stok" min="0"
                            value="<?php echo $row['stok']; ?>" required>

                        <button class="btn-small" name="ubah">Simpan</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

    <a class="btn-back" href="dashboard.php">Kembali ke Dashboard</a>
</div>

</body>
</html>

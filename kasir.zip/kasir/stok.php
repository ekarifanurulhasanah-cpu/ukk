
<?php
session_start();
include "koneksi.php";
if (isset($_POST['update'])) {
    $id = $_POST['id_produk'];
    $stok = $_POST['stok'];

    $stmt = mysqli_prepare($koneksi, "UPDATE produk SET stok=? WHERE id_produk=?");
    mysqli_stmt_bind_param($stmt, "ii", $stok, $id);
    mysqli_stmt_execute($stmt);

    header("Location: stok.php");
    exit;
}

$data = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Stok Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Stok Barang</h2>
    <a href="dashboard.php" class="btn-dashboard">Kembali ke Dashboard</a>

    <table>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Stok</th>
            <th>Status</th>
            <th>Update Stok</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['namaproduk']) ?></td>
            <td><?= $row['stok'] ?></td>
            <td>
                <?= $row['stok'] <= 5 ? 'Stok Menipis' : 'Stok Aman' ?>
            </td>
            <td>
                <form method="POST" class="form-stok">
                    <input type="hidden" name="id_produk" value="<?= $row['id_produk'] ?>">
                    <input type="number" name="stok" min="0" value="<?= $row['stok'] ?>" required>
                    <button type="submit" name="update">Update</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>

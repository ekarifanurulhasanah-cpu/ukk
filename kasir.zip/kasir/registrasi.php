
<?php
session_start();
include "koneksi.php";
$pesan = "";

if (isset($_POST['tambah'])) {
    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = "petugas";

    $cek = mysqli_prepare($koneksi, "SELECT id_user FROM users WHERE username=?");
    mysqli_stmt_bind_param($cek, "s", $username);
    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {
        $pesan = "Username sudah digunakan.";
    } else {
        $stmt = mysqli_prepare($koneksi, "INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sss", $username, $password, $role);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: registrasi.php");
            exit;
        }

        $pesan = "Registrasi gagal.";
    }
}

if (isset($_POST['update'])) {
    $id = $_POST['id_user'];
    $username = trim($_POST['username']);

    $cek = mysqli_prepare($koneksi, "SELECT id_user FROM users WHERE username=? AND id_user!=?");
    mysqli_stmt_bind_param($cek, "si", $username, $id);
    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {
        $pesan = "Username sudah digunakan.";
    } else {
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

            $stmt = mysqli_prepare($koneksi, "UPDATE users SET username=?, password=? WHERE id_user=? AND role='petugas'");
            mysqli_stmt_bind_param($stmt, "ssi", $username, $password, $id);
        } else {
            $stmt = mysqli_prepare($koneksi, "UPDATE users SET username=? WHERE id_user=? AND role='petugas'");
            mysqli_stmt_bind_param($stmt, "si", $username, $id);
        }

        if (mysqli_stmt_execute($stmt)) {
            header("Location: registrasi.php");
            exit;
        }

        $pesan = "Data gagal diperbarui.";
    }
}

if (isset($_POST['hapus'])) {
    $id = $_POST['id_user'];

    $stmt = mysqli_prepare($koneksi, "DELETE FROM users WHERE id_user=? AND role='petugas'");
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: registrasi.php");
        exit;
    }

    $pesan = "Data gagal dihapus.";
}

$edit = null;

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];

    $stmt = mysqli_prepare($koneksi, "SELECT id_user, username FROM users WHERE id_user=? AND role='petugas'");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$data = mysqli_query($koneksi, "SELECT id_user, username, role FROM users WHERE role='petugas' ORDER BY id_user DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registrasi Petugas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <h2>Registrasi Petugas</h2>

    <a href="dashboard.php">Kembali</a>

    <?php if ($pesan != "") { ?>
        <p class="error"><?= htmlspecialchars($pesan); ?></p>
    <?php } ?>

    <form method="POST">

        <input type="hidden" name="id_user" value="<?= $edit['id_user'] ?? ''; ?>">

        <input type="text" name="username"
            placeholder="Username"
            value="<?= htmlspecialchars($edit['username'] ?? ''); ?>"
            required>

        <input type="text" name="password"
            placeholder="<?= $edit ? 'Password baru (kosongkan jika tidak diganti)' : 'Password'; ?>"
            <?= $edit ? '' : 'required'; ?>>

        <?php if ($edit) { ?>

            <button type="submit" name="update">Simpan Perubahan</button>
            <a href="registrasi.php">Batal</a>

        <?php } else { ?>

            <button type="submit" name="tambah">Tambah Petugas</button>

        <?php } ?>

    </form>

    <table>
        <tr>
            <th>No</th>
            <th>Username</th>
            <th>Role</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) { ?>

        <tr>
            <td><?= $no++; ?></td>

            <td><?= htmlspecialchars($row['username']); ?></td>

            <td><?= htmlspecialchars($row['role']); ?></td>

            <td>
                <a class="btn-edit"
                   href="registrasi.php?edit=<?= $row['id_user']; ?>">
                   Edit
                </a>

                <form method="POST" class="form-aksi"
                    onsubmit="return confirm('Hapus petugas ini?')">

                    <input type="hidden" name="id_user"
                        value="<?= $row['id_user']; ?>">

                    <button type="submit" name="hapus" class="btn-hapus">
                        Hapus
                    </button>

                </form>
            </td>
        </tr>

        <?php } ?>

    </table>
</div>

</body>
</html>

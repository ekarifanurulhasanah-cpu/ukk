
<?php
session_start();
include "koneksi.php";

// CEK JUMLAH AKUN
$jumlah = mysqli_fetch_assoc(mysqli_query(
    $koneksi, "SELECT COUNT(*) AS total FROM users"
));

$adminPertama = ($jumlah['total'] == 0);

// PROSES CRUD
if (isset($_POST['aksi'])) {

    $aksi = $_POST['aksi'];
    $id = (int)($_POST['id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // TAMBAH AKUN
    if ($aksi == 'tambah') {

        if ($username == '' || strlen($password) < 6) {
            $_SESSION['pesan'] = "Username harus diisi dan password minimal 6 karakter!";
        } else {
            $cek = mysqli_prepare(
                $koneksi,
                "SELECT id FROM users WHERE username=?"
            );
            mysqli_stmt_bind_param($cek, "s", $username);
            mysqli_stmt_execute($cek);

            $hasil = mysqli_stmt_get_result($cek);

            if (mysqli_num_rows($hasil) > 0) {
                $_SESSION['pesan'] = "Username sudah digunakan!";
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $role = $adminPertama ? 'admin' : 'petugas';

                $query = mysqli_prepare(
                    $koneksi,
                    "INSERT INTO users (username, password, role)
                     VALUES (?, ?, ?)"
                );

                mysqli_stmt_bind_param(
                    $query, "sss", $username, $hash, $role
                );

                mysqli_stmt_execute($query);

                if ($adminPertama) {
                    header("Location: login.php");
                    exit;
                }

                $_SESSION['pesan'] = "Akun berhasil ditambahkan!";
            }
        }
    }

    // EDIT AKUN PETUGAS
    elseif ($aksi == 'edit' && !$adminPertama) {

        if ($id <= 0 || $username == '') {
            $_SESSION['pesan'] = "Data akun tidak valid!";
        } else {
            $cek = mysqli_prepare(
                $koneksi,
                "SELECT id FROM users WHERE username=? AND id<>?"
            );
            mysqli_stmt_bind_param($cek, "si", $username, $id);
            mysqli_stmt_execute($cek);

            $hasil = mysqli_stmt_get_result($cek);

            if (mysqli_num_rows($hasil) > 0) {
                $_SESSION['pesan'] = "Username sudah digunakan!";
            } else {
                if ($password == '') {
                    $query = mysqli_prepare(
                        $koneksi,
                        "UPDATE users SET username=?
                         WHERE id=? AND role='petugas'"
                    );
                    mysqli_stmt_bind_param($query, "si", $username, $id);
                } elseif (strlen($password) >= 6) {
                    $hash = password_hash($password, PASSWORD_DEFAULT);

                    $query = mysqli_prepare(
                        $koneksi,
                        "UPDATE users SET username=?, password=?
                         WHERE id=? AND role='petugas'"
                    );
                    mysqli_stmt_bind_param(
                        $query, "ssi", $username, $hash, $id
                    );
                } else {
                    $_SESSION['pesan'] = "Password minimal 6 karakter!";
                    header("Location: registrasi.php");
                    exit;
                }

                if (mysqli_stmt_execute($query)) {
                    $_SESSION['pesan'] = "Akun berhasil diubah!";
                }
            }
        }
    }

    // HAPUS AKUN PETUGAS
    elseif ($aksi == 'hapus' && !$adminPertama) {

        $query = mysqli_prepare(
            $koneksi,
            "DELETE FROM users WHERE id=? AND role='petugas'"
        );

        mysqli_stmt_bind_param($query, "i", $id);
        mysqli_stmt_execute($query);

        if (mysqli_stmt_affected_rows($query) > 0) {
            $_SESSION['pesan'] = "Akun berhasil dihapus!";
        } else {
            $_SESSION['pesan'] = "Akun tidak ditemukan atau tidak dapat dihapus!";
        }
    }

    header("Location: registrasi.php");
    exit;
}

// PESAN
$pesan = $_SESSION['pesan'] ?? '';
unset($_SESSION['pesan']);

// DATA UNTUK EDIT
$edit = null;

if (isset($_GET['edit']) && !$adminPertama) {

    $id = (int)$_GET['edit'];

    $query = mysqli_prepare(
        $koneksi,
        "SELECT id, username FROM users
         WHERE id=? AND role='petugas'"
    );

    mysqli_stmt_bind_param($query, "i", $id);
    mysqli_stmt_execute($query);

    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($query));
}

// MENAMPILKAN AKUN
$data = mysqli_query(
    $koneksi,
    "SELECT id, username, role FROM users ORDER BY id ASC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registrasi Akun</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <h2>Manajemen Akun</h2>

    <?php if ($pesan != '') { ?>
        <div class="alert">
            <?php echo htmlspecialchars($pesan); ?>
        </div>
    <?php } ?>

    <!-- FORM TAMBAH DAN EDIT -->
    <div class="form-box">

        <h3>
            <?php
            if ($adminPertama) {
                echo "Buat Admin Pertama";
            } elseif ($edit) {
                echo "Edit Akun Petugas";
            } else {
                echo "Tambah Akun Petugas";
            }
            ?>
        </h3>

        <form method="POST">

            <input type="hidden" name="aksi"
                value="<?php echo $edit ? 'edit' : 'tambah'; ?>">

            <input type="hidden" name="id"
                value="<?php echo $edit['id'] ?? ''; ?>">

            <label>Username</label>
            <input type="text" name="username"
                value="<?php echo htmlspecialchars($edit['username'] ?? ''); ?>"
                required>
                <br><br>

            <label>Password</label>
            <input type="text" name="password"
                placeholder="<?php echo $edit ? 'Kosongkan jika tidak diubah' : 'Masukkan password'; ?>"
                <?php echo $edit ? '' : 'required'; ?>>
                <br><br>

            <button type="submit" class="btn">
                <?php echo $edit ? 'Update Akun' : 'Tambah Akun'; ?>
            </button>

            <?php if ($edit) { ?>
                <a href="registrasi.php" class="btn-back">Batal</a>
            <?php } ?>

        </form>

    </div>

    <?php if (!$adminPertama) { ?>

    <!-- DAFTAR AKUN -->
    <h3>Daftar Pengguna</h3>

    <div class="table-wrap">
        <table>

            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>

            <?php $no = 1; ?>

            <?php while ($row = mysqli_fetch_assoc($data)) { ?>

            <tr>
                <td><?php echo $no++; ?></td>

                <td>
                    <?php echo htmlspecialchars($row['username']); ?>
                </td>

                <td>
                    <?php echo ucfirst($row['role']); ?>
                </td>

                <td>

                    <?php if ($row['role'] == 'petugas') { ?>

                        <a href="registrasi.php?edit=<?php echo $row['id']; ?>"
                           class="btn-small">
                            Edit
                        </a>
                            <input type="hidden" name="aksi" value="hapus">
                            <input type="hidden" name="id"
                                value="<?php echo $row['id']; ?>">

                            <button type="submit"
                                class="btn-small btn-danger">
                                Hapus
                            </button>
                    <?php } else { ?>

                        <span>Akun Admin</span>

                    <?php } ?>

                </td>
            </tr>

            <?php } ?>

        </table>
    </div>

    <a href="dashboard.php" class="btn-back">
        Kembali ke Dashboard
    </a>

    <?php } ?>

</div>

</body>
</html>

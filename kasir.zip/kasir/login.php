<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Kasir</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="login-container">
    <h2>Login Aplikasi Kasir</h2>

    <form action="proses_login.php" method="POST">
        <label>Username</label>
        <input type="text" name="username" placeholder="Username" required>
        <label>Password</label>
        <input type="text" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>

    <?php if (isset($_GET['pesan'])) { ?>
        <p class="error">Username atau password salah!</p>
    <?php } ?>
</div>

</body>
</html>
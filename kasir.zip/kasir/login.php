
<?php
session_start();

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin') {
        header("Location: dashboard.php");
        exit;
    } elseif ($_SESSION['role'] == 'petugas') {
        header("Location: dashboard_petugas.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Aplikasi Kasir</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Login Aplikasi Kasir</h2>

    <?php
    if (isset($_GET['pesan'])) {
        echo "<p style='color:red;'>Username atau password salah!</p>";
    }
    ?>

    <form action="proses_login.php" method="POST">
        <label>Username</label>
        <input type="text" name="username"
               placeholder="Masukkan username" required>
               <br><br>

        <label>Password</label>
        <input type="text" name="password"
               placeholder="Masukkan password" required>
               <br><br>

        <button type="submit" name="login">Login</button>
    </form>
</div>

</body>
</html>

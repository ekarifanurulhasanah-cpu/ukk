
<?php
session_start();
include "koneksi.php";
if (isset($_POST['simpan'])) {
    $nama = $_POST['namaproduk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = mysqli_prepare($koneksi, "INSERT INTO produk (namaproduk, harga, stok) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sii", $nama, $harga, $stok);
    mysqli_stmt_execute($stmt);

    header("Location: pendataan.php");
    exit;
}

if (isset($_POST['update'])) {
    $id = $_POST['id_produk'];
    $nama = $_POST['namaproduk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = mysqli_prepare($koneksi, "UPDATE produk SET namaproduk=?, harga=?, stok=? WHERE id_produk=?");
    mysqli_stmt_bind_param($stmt, "siii", $nama, $harga, $stok, $id);
    mysqli_stmt_execute($stmt);

    header("Location: pendataan.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    $stmt = mysqli_prepare($koneksi, "DELETE FROM produk WHERE id_produk=?");
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (!mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Barang tidak dapat dihapus karena sudah digunakan dalam transaksi.'); window.location='pendataan.php';</script>";
        exit;
    }

    header("Location: pendataan.php");
    exit;
}

$edit = null;

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM produk WHERE id_produk=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$data = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pendataan Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Pendataan Barang</h2>
    <a href="dashboard.php" class="btn-dashboard">Kembali ke Dashboard</a>

    <form method="POST">
        <input type="hidden" name="idproduk" value="<?= $edit['id_produk'] ?? '' ?>">

        <label>Nama Barang</label>
        <input type="text" name="namaproduk" value="<?= htmlspecialchars($edit['namaproduk'] ?? '') ?>" required>

        <label>Harga</label>
        <input type="number" name="harga" value="<?= $edit['harga'] ?? '' ?>" min="0" required>

        <label>Stok</label>
        <input type="number" name="stok" value="<?= $edit['stok'] ?? '' ?>" min="0" required>

        <?php if ($edit) { ?>
            <button type="submit" name="update">Update Barang</button>
            <a href="pendataan.php" class="btn-batal">Batal</a>
        <?php } else { ?>
            <button type="submit" name="simpan">Tambah Barang</button>
        <?php } ?>
    </form>

    <h3>Daftar Barang</h3>
    <table>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['namaproduk']) ?></td>
            <td>Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
            <td><?= $row['stok'] ?></td>
            <td>
                <a class="btn-edit" href="pendataan.php?edit=<?= $row['id_produk'] ?>">Edit</a>
                <a class="btn-hapus" href="pendataan.php?hapus=<?= $row['id_produk'] ?>" onclick="return confirm('Hapus barang ini?')">Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>

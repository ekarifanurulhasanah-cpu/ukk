
<?php
session_start();
include "koneksi.php";
$pesan = "";

// PROSES TAMBAH, EDIT, HAPUS
if (isset($_POST['aksi'])) {

    $aksi = $_POST['aksi'];
    $id = (int)($_POST['idproduk'] ?? 0);

    // TAMBAH BARANG
    if ($aksi == 'tambah') {

        $nama = trim($_POST['namaproduk']);
        $harga = filter_var($_POST['harga'], FILTER_VALIDATE_FLOAT);
        $stok = filter_var($_POST['stok'], FILTER_VALIDATE_INT);

        if ($nama == "" || $harga === false || $harga < 0 ||
            $stok === false || $stok < 0) {
            $_SESSION['pesan'] = "Data barang tidak valid!";
        } else {
            $query = mysqli_prepare(
                $koneksi,
                "INSERT INTO produk (namaproduk, harga, stok)
                 VALUES (?, ?, ?)"
            );

            mysqli_stmt_bind_param($query, "sdi", $nama, $harga, $stok);
            mysqli_stmt_execute($query);

            $_SESSION['pesan'] = "Barang berhasil ditambahkan!";
        }
    }

    // EDIT BARANG
    elseif ($aksi == 'edit') {

        $nama = trim($_POST['namaproduk']);
        $harga = filter_var($_POST['harga'], FILTER_VALIDATE_FLOAT);
        $stok = filter_var($_POST['stok'], FILTER_VALIDATE_INT);

        if ($id <= 0 || $nama == "" || $harga === false ||
            $harga < 0 || $stok === false || $stok < 0) {
            $_SESSION['pesan'] = "Data barang tidak valid!";
        } else {
            $query = mysqli_prepare(
                $koneksi,
                "UPDATE produk
                 SET namaproduk=?, harga=?, stok=?
                 WHERE idproduk=?"
            );

            mysqli_stmt_bind_param(
                $query, "sdii", $nama, $harga, $stok, $id
            );

            mysqli_stmt_execute($query);

            $_SESSION['pesan'] = "Barang berhasil diubah!";
        }
    }

    // HAPUS BARANG
    elseif ($aksi == 'hapus') {

        $query = mysqli_prepare(
            $koneksi,
            "DELETE FROM produk WHERE idproduk=?"
        );

        mysqli_stmt_bind_param($query, "i", $id);
        mysqli_stmt_execute($query);

        $_SESSION['pesan'] = "Barang berhasil dihapus!";
    }

    header("Location: pendataan.php");
    exit;
}

// PESAN
if (isset($_SESSION['pesan'])) {
    $pesan = $_SESSION['pesan'];
    unset($_SESSION['pesan']);
}

// DATA EDIT
$edit = null;

if (isset($_GET['edit'])) {

    $id = (int)$_GET['edit'];

    $query = mysqli_prepare(
        $koneksi,
        "SELECT * FROM produk WHERE idproduk=?"
    );

    mysqli_stmt_bind_param($query, "i", $id);
    mysqli_stmt_execute($query);

    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($query));
}

// MENAMPILKAN BARANG
$data = mysqli_query(
    $koneksi,
    "SELECT * FROM produk ORDER BY namaproduk ASC"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pendataan Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">

    <h2>Pendataan Barang</h2>

    <?php if ($pesan != "") { ?>
        <div class="alert">
            <?php echo htmlspecialchars($pesan); ?>
        </div>
    <?php } ?>

    <!-- FORM TAMBAH DAN EDIT -->
    <div class="form-box">

        <h3>
            <?php echo $edit ? "Edit Barang" : "Tambah Barang"; ?>
        </h3>

        <form method="POST">

            <input type="hidden" name="aksi"
                value="<?php echo $edit ? 'edit' : 'tambah'; ?>">

            <input type="hidden" name="idproduk"
                value="<?php echo $edit['idproduk'] ?? ''; ?>">

            <label>Nama Produk</label>
            <input type="text" name="namaproduk"
                value="<?php echo htmlspecialchars($edit['namaproduk'] ?? ''); ?>"
                required>
            <br><br>
            <label>Harga</label>
            <input type="number" name="harga"
                min="0" step="0.01"
                value="<?php echo $edit['harga'] ?? ''; ?>"
                required>
            <br><br>
            <label>Stok</label>
            <input type="number" name="stok"
                min="0"
                value="<?php echo $edit['stok'] ?? ''; ?>"
                required>
                <br><br>
            <button type="submit" class="btn">
                <?php echo $edit ? "Update Barang" : "Tambah Barang"; ?>
            </button>

            <?php if ($edit) { ?>
                <a href="pendataan.php" class="btn-back">
                    Batal
                </a>
            <?php } ?>

        </form>

    </div>

    <!-- DAFTAR BARANG -->
    <h3>Daftar Barang</h3>

    <div class="table-wrap">

        <table>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>

            <?php $no = 1; ?>

            <?php while ($row = mysqli_fetch_assoc($data)) { ?>

            <tr>
                <td><?php echo $no++; ?></td>

                <td>
                    <?php echo htmlspecialchars($row['namaproduk']); ?>
                </td>

                <td>
                    Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?>
                </td>

                <td><?php echo $row['stok']; ?></td>

                <td>
                    <a href="pendataan.php?edit=<?php echo $row['idproduk']; ?>"
                       class="btn-small">
                        Edit
                    </a>
                        <input type="hidden" name="aksi" value="hapus">

                        <input type="hidden" name="idproduk"
                            value="<?php echo $row['idproduk']; ?>">

                        <button type="submit"
                            class="btn-small btn-danger">
                            Hapus
                        </button>
                </td>
            </tr>

            <?php } ?>

        </table>

    </div>
     <a class="btn-back" href="dashboard_petugas.php">Kembali ke Dashboard</a>
</div>

</body>
</html>


<?php
session_start();
include "koneksi.php";
if (isset($_POST['simpan'])) {
    $pelanggan = $_POST['id_pelanggan'];
    $produk = $_POST['id_produk'];
    $jumlah = $_POST['jumlah_produk'];

    if ($jumlah < 1) {
        echo "<script>alert('Jumlah barang tidak valid.'); window.location='transaksi.php';</script>";
        exit;
    }
    mysqli_begin_transaction($koneksi);
    try {
        $stmt = mysqli_prepare($koneksi, "SELECT harga, stok FROM produk WHERE id_produk=? FOR UPDATE");
        mysqli_stmt_bind_param($stmt, "i", $produk);
        mysqli_stmt_execute($stmt);
        $barang = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if (!$barang || $barang['stok'] < $jumlah) {
            throw new Exception("Stok barang tidak mencukupi.");
        }

        $subtotal = $barang['harga'] * $jumlah;
        $tanggal = date('Y-m-d');

        $stmt = mysqli_prepare($koneksi, "INSERT INTO penjualan (tgl_penjual, total_harga, id_pelanggan) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sii", $tanggal, $subtotal, $pelanggan);
        mysqli_stmt_execute($stmt);

        $id_penjualan = mysqli_insert_id($koneksi);

        $stmt = mysqli_prepare($koneksi, "INSERT INTO detailpenjualan (id_penjualan, id_produk, jumlah_produk, subtotal) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "iiii", $id_penjualan, $produk, $jumlah, $subtotal);
        mysqli_stmt_execute($stmt);

        $stmt = mysqli_prepare($koneksi, "UPDATE produk SET stok = stok - ? WHERE id_produk=?");
        mysqli_stmt_bind_param($stmt, "ii", $jumlah, $produk);
        mysqli_stmt_execute($stmt);

        mysqli_commit($koneksi);

        header("Location: transaksi.php");
        exit;
    } catch (Exception $e) {
        mysqli_rollback($koneksi);
        echo "<script>alert(" . json_encode($e->getMessage()) . "); window.location='transaksi.php';</script>";
        exit;
    }
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    mysqli_begin_transaction($koneksi);

    try {
        $stmt = mysqli_prepare($koneksi, "SELECT id_produk, jumlah_produk FROM detailpenjualan WHERE id_penjualan=?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $detail = mysqli_stmt_get_result($stmt);

        while ($row = mysqli_fetch_assoc($detail)) {
            $stmt2 = mysqli_prepare($koneksi, "UPDATE produk SET stok = stok + ? WHERE id_produk=?");
            mysqli_stmt_bind_param($stmt2, "ii", $row['jumlah_produk'], $row['id_produk']);
            mysqli_stmt_execute($stmt2);
        }

        $stmt = mysqli_prepare($koneksi, "DELETE FROM detailpenjualan WHERE id_penjualan=?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);

        $stmt = mysqli_prepare($koneksi, "DELETE FROM penjualan WHERE id_penjualan=?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);

        mysqli_commit($koneksi);
    } catch (Exception $e) {
        mysqli_rollback($koneksi);
        die("Transaksi gagal dihapus: " . htmlspecialchars($e->getMessage()));
    }

    header("Location: transaksi.php");
    exit;
}

$pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan ORDER BY nama_pelanggan");
$produk = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY nama_produk");

$data = mysqli_query($koneksi, "
    SELECT penjualan.*, pelanggan.nama_pelanggan,
    GROUP_CONCAT(CONCAT(produk.nama_produk, ' (', detailpenjualan.jumlah_produk, ')') SEPARATOR ', ') AS barang
    FROM penjualan
    JOIN pelanggan ON penjualan.id_pelanggan = pelanggan.id_pelanggan
    LEFT JOIN detailpenjualan ON penjualan.id_penjualan = detailpenjualan.id_penjualan
    LEFT JOIN produk ON detailpenjualan.id_produk = produk.id_produk
    GROUP BY penjualan.id_penjualan
    ORDER BY penjualan.id_penjualan DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Transaksi Penjualan</h2>
    <a href="dashboard.php" class="btn-dashboard">Kembali ke Dashboard</a>

    <form method="POST">
        <label>Pelanggan</label>
        <select name="id_pelanggan" required>
            <option value="">Pilih Pelanggan</option>
            <?php while ($p = mysqli_fetch_assoc($pelanggan)) { ?>
                <option value="<?= $p['id_pelanggan'] ?>">
                    <?= htmlspecialchars($p['nama_pelanggan']) ?>
                </option>
            <?php } ?>
        </select>

        <label>Barang</label>
        <select name="id_produk" required>
            <option value="">Pilih Barang</option>
            <?php while ($b = mysqli_fetch_assoc($produk)) { ?>
                <option value="<?= $b['id_produk'] ?>">
                    <?= htmlspecialchars($b['nama_produk']) ?> - Rp<?= number_format($b['harga'], 0, ',', '.') ?> (Stok: <?= $b['stok'] ?>)
                </option>
            <?php } ?>
        </select>

        <label>Jumlah</label>
        <input type="number" name="jumlah_produk" min="1" required>

        <button type="submit" name="simpan">Simpan Transaksi</button>
    </form>

    <h3>Daftar Transaksi</h3>
    <table>
        <tr>
            <th>No</th>
            <th>Tanggal</th>
            <th>Pelanggan</th>
            <th>Barang</th>
            <th>Total Harga</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['tgl_penjual'] ?></td>
            <td><?= htmlspecialchars($row['nama_pelanggan']) ?></td>
            <td><?= htmlspecialchars($row['barang'] ?? '-') ?></td>
            <td>Rp<?= number_format($row['total_harga'], 0, ',', '.') ?></td>
            <td>
                <a class="btn-hapus" href="transaksi.php?hapus=<?= $row['id_penjualan'] ?>" onclick="return confirm('Hapus transaksi ini? Stok barang akan dikembalikan.')">Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>

<!DOCTYPE html>
<html>
<body>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <div class="container">
        <h3>Anda berhasil login dan Selamat Datang Administrator.</h3>
        <a href="registrasi.php">Registrasi</a>
        <br><br>
        <a href="pendataan.php">Pendataan Barang</a>
        <br><br>
        <a href="stok.php">Stok Barang</a>
        <br><br>
        <a href="logout.php">Logout</a>
    </div>

</body>
</html>

<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Dashboard Admin</h2>
    <p>Selamat datang, <?= htmlspecialchars($_SESSION['username']); ?></p>

    <div class="dashboard-menu"> 
        <a href="registrasi.php">Registrasi Petugas</a>
        <br><br>
        <a href="pendataan.php">Pendataan Barang</a>
        <br><br>
        <a href="stok.php">Stok Barang</a>
        <br><br>
        <a href="pelanggan.php">Data Pelanggan</a>
        <br><br>
        <a href="transaksi.php">Transaksi</a>
        <br><br>
        <a href="logout.php">Logout</a>
    </div>
</div>

</body>
</html>
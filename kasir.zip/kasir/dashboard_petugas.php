<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Petugas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Dashboard Petugas</h2>
    <p>Selamat datang, <?= htmlspecialchars($_SESSION['username']); ?></p>

    <div class="dashboard-menu">
        <a href="pendataan.php">Pendataan Barang</a>
        <a href="stok_petugas.php">Stok Barang</a>
        <a href="pelanggan.php">Data Pelanggan</a>
        <a href="transaksi.php">Transaksi</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

</body>
</html>
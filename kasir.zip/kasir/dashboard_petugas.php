<!DOCTYPE html>
<html>
<body>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
    <div class="container">
        <h3>Anda berhasil login dan Selamat Datang Petugass.</h3>
        <a href="pendataan.php">Pendataan Barang</a>
        <br><br>
        <a href="stok.php">Stok Barang</a>
        <br><br>
        <a href="logout.php">Logout</a>
    </div>

</body>
</html>

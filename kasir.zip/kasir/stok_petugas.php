
<?php
session_start();
include "koneksi.php";
if (isset($_POST['tambah'])) {
    $nama = $_POST['namaproduk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = mysqli_prepare($koneksi, "INSERT INTO produk (namaproduk, harga, stok) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sii", $nama, $harga, $stok);
    mysqli_stmt_execute($stmt);

    header("Location: stok_petugas.php");
    exit;
}

if (isset($_POST['update'])) {
    $id = $_POST['idproduk'];
    $nama = $_POST['namaproduk'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $stmt = mysqli_prepare($koneksi, "UPDATE produk SET namaproduk=?, harga=?, stok=? WHERE idproduk=?");
    mysqli_stmt_bind_param($stmt, "siii", $nama, $harga, $stok, $id);
    mysqli_stmt_execute($stmt);

    header("Location: stok_petugas.php");
    exit;
}

if (isset($_POST['hapus'])) {
    $id = $_POST['idproduk'];

    $stmt = mysqli_prepare($koneksi, "DELETE FROM produk WHERE idproduk=?");
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: stok_petugas.php");
        exit;
    }

    $pesan = "Barang tidak dapat dihapus karena sudah digunakan dalam transaksi.";
}

$edit = null;

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM produk WHERE idproduk=?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$data = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY idproduk DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD Stok Petugas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Data Stok Barang</h2>
    <a href="dashboard_petugas.php">Kembali</a>

    <?php if (isset($pesan)) { ?>
        <p class="error"><?= htmlspecialchars($pesan); ?></p>
    <?php } ?>

    <form method="POST">
        <input type="hidden" name="idproduk" value="<?= $edit['idproduk'] ?? ''; ?>">

        <input type="text" name="namaproduk"
            placeholder="Nama Barang"
            value="<?= htmlspecialchars($edit['namaproduk'] ?? ''); ?>" required>

        <input type="number" name="harga"
            placeholder="Harga"
            min="0"
            value="<?= $edit['harga'] ?? ''; ?>" required>

        <input type="number" name="stok"
            placeholder="Jumlah Stok"
            min="0"
            value="<?= $edit['stok'] ?? ''; ?>" required>

        <?php if ($edit) { ?>
            <button type="submit" name="update">Simpan Perubahan</button>
            <a href="stok_petugas.php">Batal</a>
        <?php } else { ?>
            <button type="submit" name="tambah">Tambah Barang</button>
        <?php } ?>
    </form>

    <table>
        <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) { ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= htmlspecialchars($row['namaproduk']); ?></td>
            <td>Rp<?= number_format($row['harga'], 0, ',', '.'); ?></td>
            <td><?= $row['stok']; ?></td>
            <td><?= $row['stok'] <= 5 ? 'Stok Menipis' : 'Tersedia'; ?></td>
            <td>
                <a class="btn-edit" href="stok_petugas.php?edit=<?= $row['idproduk']; ?>">Edit</a>

                <form method="POST" class="form-aksi" onsubmit="return confirm('Hapus barang ini?')">
                    <input type="hidden" name="idproduk" value="<?= $row['idproduk']; ?>">
                    <button type="submit" name="hapus" class="btn-hapus">Hapus</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>

</body>
</html>
